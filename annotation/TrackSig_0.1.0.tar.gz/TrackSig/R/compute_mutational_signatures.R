# compute_mutational_signatures.R
# AUTHOR: Yulia Rubanova
# Modified for package TrackSig by Cait Harrigan

#' Functions to compute mutational signatures
#'
#' @param dir_counts Directory where previously computed mutation counts are \cr
#' located. Defaults to TrackSig.options()$DIR_COUNTS
#' @param bootstrap_counts Directory where previously computed mutation bootstrapped\cr
#' counts are located. Defaults toTrackSig.options()$BOOTSTRAP_COUNTS
#'
#' @seealso \link{options-TrackSig}
#'
#' @rdname compute_mutational_signatures
#' @name compute_mutational_signatures
NULL


#' \code{save_data_for_samples} Load previously computed mutation count data and save as RData
#'
#' @note save_data_for_samples() DEPRICATED: use load_data_for_samples() instead
#' @rdname compute_mutational_signatures

save_data_for_samples <- function(dir_counts = TrackSig.options()$DIR_COUNTS,
                                  bootstrap_counts = TrackSig.options()$BOOTSTRAP_COUNTS){
  warning("save_data_for_samples is deprecated.")
  print("Step 1: pre-processing")

  if (!file.exists(TrackSig.options()$SAVED_SAMPLES_DIR)) {
    dir.create(TrackSig.options()$SAVED_SAMPLES_DIR, recursive = T)
  }

  if (simulated_data) {
    tumors <- list.files(dir_counts, recursive=T)
    tumors <- tumors[grepl("([^/]*)\\d\\.csv", tumors)]
    tumors <- gsub("([^/]*)\\.csv","\\1", tumors)
  } else {
    tumors <- gsub("([^/]*)\\.phi\\.txt","\\1", list.files(dir_counts))
  }

  examples_group <- get_examples_group(tumors)

  for (example in examples_group)
  {
    print(paste0("Example ", example, " (", which(examples_group == example), " out of ", length(examples_group), ")"))

    if (TrackSig.options()$simulated_data) {
      list[tumor_id, vcfData, phis, acronym, dir_name] <- extract_data_for_simulation(example, dir_counts, dir_create = F)
    } else {
      list[tumor_id, vcfData, phis, assigns_phylo_nodes, acronym, dir_name] <- extract_data_for_example(example, dir_counts, tumortypes, dir_create = F)
    }

    if (is.null(vcfData))
    {
      print(paste0("No data read for example ", example))
      next
    }
    if (nrow(vcfData) == 0)
    {
      print(paste0("Zero rows for example " , example))
      next
    }
    if (nrow(vcfData) < 6) # Plots with less than 6 lines of data are meaningless so ignored
    {
      print(paste0("Less than 6 rows per example ", example))
      next
    }

    if (sliding_window) {
      # Sliding window approach
      data_method <- "sliding400"
      window_size=400
      shift = window_size/100
      gap = 1
      vcf <- get_sliding_window_data(vcfData, shift=shift, gap = gap)
      phis_sliding_window <- get_sliding_window_data(toVerticalMatrix(phis), shift=shift)
      phis_sliding_window <- phis_sliding_window / shift

      phis_for_plot = phis_sliding_window
    } else {
      shift <- gap <- NULL
      data_method <- "chunk100"
      vcf <- t(vcfData)
      phis_for_plot <- phis_sliding_window <- phis
    }

    if (!TrackSig.options()$simulated_data) {
      purity = get_sample_purity(example)
      phis_for_plot = phis_for_plot / purity

      if (sum(phis_sliding_window < 0.001) > 0.2 * length(phis_sliding_window))
      {
        phis_for_plot = NULL
      }

      if (!is.null(phis_for_plot))
      {
        colnames(vcf) <- round(phis_sliding_window, 3)
      } else {
        colnames(vcf) <- NULL
      }

      if (!is.null(assigns_phylo_nodes))
      {
        assigns_phylo_nodes <-  as.factor(assigns_phylo_nodes)
        assigns_phylo_nodes_levels <- levels(assigns_phylo_nodes)
        assigns_phylo_nodes <- toVerticalMatrix(as.numeric(assigns_phylo_nodes))

        if (sliding_window) {
          assigns_phylo_nodes_sw <- get_sliding_window_data(assigns_phylo_nodes, shift=shift)
          assigns_phylo_nodes_sw <- assigns_phylo_nodes_sw / shift
          assigns_phylo_nodes_sw <- round(assigns_phylo_nodes_sw)
        } else {
          assigns_phylo_nodes_sw <- assigns_phylo_nodes
        }

        for (l in 1:length(assigns_phylo_nodes_levels))
        {
          assigns_phylo_nodes_sw[assigns_phylo_nodes_sw == l] <- assigns_phylo_nodes_levels[l]
        }

        stopifnot(length(phis_for_plot) == length(assigns_phylo_nodes_sw))
      } else {
        assigns_phylo_nodes_sw = assigns_phylo_nodes
      }

      list[bootstrap_vcfs, bootstrap_phis] <- lapply(extract_bootstrap_data_for_example(example, bootstrap_counts), t)

      if (compute_bootstrap) {
        for (j in 1:length(bootstrap_phis))
        {
          if (sliding_window) {
            bootstrap_vcfs[[j]] <- get_sliding_window_data(bootstrap_vcfs[[j]], shift=shift, gap = gap)
            bootstrap_phis[[j]] <- get_sliding_window_data(toVerticalMatrix(bootstrap_phis[[j]]), shift=shift)
            bootstrap_phis[[j]] <- bootstrap_phis[[j]] / shift
          }
        }
      }
    }

    if (TrackSig.options()$simulated_data) {
      dir.create(paste0(TrackSig.options()$SAVED_SAMPLES_DIR, "/", acronym, "/"), showWarnings=F, recursive=T)
      assigns_phylo_nodes = assigns_phylo_nodes_sw = bootstrap_vcfs = bootstrap_phis = bootstrap_vcfs_unsorted = NULL
    }

    save(vcfData, vcf, phis, phis_sliding_window, assigns_phylo_nodes, assigns_phylo_nodes_sw,
         acronym, window, shift, gap, tumor_id, phis_for_plot, bootstrap_vcfs, bootstrap_phis,
         file = paste0(TrackSig.options()$SAVED_SAMPLES_DIR, "/", example, ".RData"))
  }
}


#' \code{compute_signatures_for_all_examples} Compute mutational signatures and \cr
#' find changepoints
#'
#' @rdname compute_mutational_signatures
#' @export

# NO LONGER USED -- use similar function in TrackSig/R/load_all_samples.R
compute_signatures_for_all_examples <- function(dir_counts = TrackSig.options()$DIR_COUNTS){
  print("Step 2: computing signature activities")

  add_early_late_transition = TRUE

  age_signatures <- c("S1", "S5", "L1", "1", "5a", "5b")

  if (TrackSig.options()$simulated_data) {
    tumors <- list.files(dir_counts, recursive=T)
    tumors <- tumors[grepl("([^/]*)\\d\\.csv", tumors)]
    tumors <- gsub("([^/]*)\\.csv","\\1", tumors)
  } else {
    tumors <- gsub("([^/]*)\\.phi\\.txt","\\1", list.files(dir_counts))
  }

  examples_group <- get_examples_group(tumors)

  mutation_types <- read.delim(trinucleotide_file, header=F)
  mutation_types <- paste(mutation_types[,1], mutation_types[,2], mutation_types[,3], sep="_")

  for (example in examples_group)
  {
    set.seed(which(examples_group == example))
    print(paste0("Example ", example, " (", which(examples_group == example), " out of ", length(examples_group), ")"))

    data_file = paste0(TrackSig.options()$SAVED_SAMPLES_DIR, "/", example, ".RData")
    if (file.exists(data_file))
    {
      load(data_file)
    } else {
      print(paste0("Data file ", data_file, " does not exist"))
      next
    }

    if (TrackSig.options()$simulated_data){
      active_sigs <- data.frame(tumor_type = acronym, ID = tumor_id, Name = acronym, toHorizontalMatrix(rep(0, ncol(alex))), stringsAsFactors=F)
      colnames(active_sigs) <- c("tumor_type", "ID", "Name", colnames(alex))

      active <- sapply(read.csv(paste0(DIR_COUNTS, "/", example, ".exposure.csv"), header=F)[,1], toString)
      active_sigs[,active] <- 1

      list[alex.t, matched_type, acronym] <- get_signatures_for_current_sample(tumor_id, active_sigs, alex, noise_sig)
    } else {
      if (sig_amount == "onlyKnownSignatures") {
        # Fit only known signatures
        list[alex.t, matched_type, acronym] <- get_signatures_for_current_sample(tumor_id, active_signatures.our_samples, alex, noise_sig)
      } else {
        alex.t <- alex
      }
    }

    if (is.null(acronym) || acronym == "") {
      print(paste("ERROR: Cancer type not found for ", example))
      next
    }

    if (is.null(alex.t))
    {
      print(paste0("No active signatures for sample", example, " ...."))
      next
    }

    if (is.vector(alex.t)) {
      next
    }

    if (sum(vcf[apply(alex.t,1,sum) == 0,] != 0) != 0) {
      print(paste0("Sample ", example, ": some trinucleotides have probability 0 under the model, but their count is non-zero. Sot the count vector is impossible under the model."))
      next
    }

    dir_name <- paste0(DIR_RESULTS, acronym, "/", tumor_id, "/")

    suppressWarnings(dir.create(dir_name, recursive = T))

    if (!is.null(phis_for_plot))
    {
      write(phis_for_plot, file=paste0(dir_name, "phis.txt"), ncolumns=length(phis_for_plot))
    }

    method_name <- "iterativeChangePoints"

    if (!file.exists(paste0(dir_name, "mixtures.csv")) || !file.exists(paste0(dir_name, "changepoints.txt")))
    {
      if (TrackSig.options()$changepoint_method == "PELT") {
        list[changepoints, mixtures] <- find_changepoints_pelt(vcf, alex.t)
      } else {
        list[bics, optimal, changepoints, mixtures] <- find_changepoints_over_all_signatures_one_by_one(vcf, alex.t, n_signatures = ncol(alex.t))
      }

      write.csv(mixtures, file=paste0(dir_name, "mixtures.csv"))

      n_col <- ifelse(length(changepoints) > 0, length(changepoints), 1)
      write(changepoints, file=paste0(dir_name, "changepoints.txt"), ncolumns=n_col)
    } else {
      mixtures <- read_mixtures(paste0(dir_name, "mixtures.csv"))
      cp_file = paste0(dir_name, "changepoints.txt")
      if (file.info(cp_file)$size == 1) {
        changepoints <- c()
      } else {
        changepoints <- unlist(read.table(cp_file, header=F))
      }
    }

    if (!is.null(assigns_phylo_nodes_sw)) {
      write(assigns_phylo_nodes_sw,  file=paste0(dir_name, "assignments.txt"), ncolumns=length(assigns_phylo_nodes_sw))
    } else  {
      n_clusters = transition_points = assigns_phylo_nodes_sw = NULL
    }

    age_signatures <- intersect(rownames(mixtures), age_signatures)

    if (TrackSig.options()$simulated_data) {
      plot_name <- paste0(dir_name, "/", tumor_id,  ".pdf")
    } else {
      plot_name <- paste0(dir_name, "/", acronym, "_", tumor_id, "_", sig_amount, postfix, ".pdf")
    }

    if (PLOT_FULL_NAME)
    {
      plot_name <- paste0(dir_name, "/", acronym, "_", data_method, "_multMix_fittedPerTimeSlice_", sig_amount, "_noPrior_", method_name, postfix, ".pdf")
    }

    mark_cp <- !is.null(changepoints)
    plot_signatures(mixtures*100, plot_name=plot_name, phis = phis_for_plot, mark_change_points=mark_cp, change_points=changepoints,
                    #assigns_phylo_nodes = assigns_phylo_nodes_sw,
                    transition_points = transition_points,
                    scale=1.2)

    mixtures.rescaled = NULL

    print(paste("Computed example", example))
  }

}

#' \code{compute_errorbars_for_all_examples} Compute mutational signatures and \cr
#' find changepoints, bootstrapped to estimate certainty
#'
#' @rdname compute_mutational_signatures
#' @export

compute_errorbars_for_all_examples <- function(bootstrap_counts = TrackSig.options()$BOOTSTRAP_COUNTS){
  print("Step 3: computing signature activities on bootstrapped data (optional)")
  add_early_late_transition = TRUE

  tumors <- list.dirs(bootstrap_counts, recursive = F, full.names=F)
  examples_group <- get_examples_group(tumors)

  for (example in examples_group)
  {
    set.seed(which(examples_group == example))
    print(paste0("Example ", example, " (", which(examples_group == example), " out of ", length(examples_group), ")"))

    data_file = paste0(TrackSig.options()$SAVED_SAMPLES_DIR, "/", example, ".RData")
    if (file.exists(data_file)) {
      load(data_file)
    } else {
      print(paste0("Data file ", data_file, " does not exist"))
      next
    }

    max_tp = 100
    # do not compute bootstrap for samples with number of time points > max_tp
    if (ncol(vcf) > max_tp) {
      print(paste0("Skipping ", example, ": more than ", max_tp, " timepoints"))
      next
    }

    if (sig_amount == "onlyKnownSignatures") {
      # Fit only known signatures
      list[alex.t, matched_type, acronym] <- get_signatures_for_current_sample(tumor_id, active_signatures.our_samples, alex, noise_sig)
    } else if (sig_amount == "selectedSignatures") {
      selected = c("S1", "S3", "S5", "S8", "S9", "S16")
      alex.t <- alex[,selected]
    } else {
      alex.t <- alex
    }

    if (is.null(alex.t)) {
      print(paste0("No active signatures for sample", example, " ...."))
      next
    }

    if (acronym == "") {
      print(paste("Cancer type not found for ", tumor_id))
      next
    }

    dir_name <- paste0(DIR_RESULTS, acronym, "/", tumor_id, "/")
    suppressWarnings(dir.create(dir_name, recursive = T))

    method_name <- "iterativeChangePoints"

    if (!file.exists(paste0(dir_name, "mixtures.csv"))) {
      next
    }
    mixtures <- read_mixtures(paste0(dir_name, "mixtures.csv"))
    changepoints <- tryCatch({
      unlist(read.table(paste0(dir_name, "changepoints.txt"), header=F))
    }, error = function(e){return()})

    print("Computing bootstrapped trajectories")
    list[mixtures_bootstrap, changepoints_bootstrap] <- get_bootstrap_mixtures(bootstrap_vcfs, bootstrap_phis, alex.t, dir_name, "")
    list[mixtures.mean, mixtures.sd, mixtures.err] <- compute_mean_sd_err(mixtures_bootstrap, rownames(mixtures), dir_name)

    transition_points = NULL
    plot_name <- paste0(dir_name, "/", acronym, "_", example, "_", sig_amount)

    if (PLOT_FULL_NAME)
    {
      plot_name <- paste0(dir_name, "/", acronym, "_", data_method, "_multMix_fittedPerTimeSlice_", sig_amount, "_noPrior_", method_name, postfix)
    }

    plot_signatures(mixtures.mean*100, plot_name=paste0(plot_name, ".mean.bootstrap_traj.pdf"), phis = phis_for_plot,
                    mark_change_points=T,
                    change_points=changepoints,
                    transition_points = transition_points,
                    fitted_data = lapply(mixtures_bootstrap, function(x) x* 100))
                    #assigns_phylo_nodes = assigns_phylo_nodes_sw) #error_bars = mixtures.err)

    plot_signatures_real_scale(mixtures.mean*100, plot_name=paste0(plot_name, ".mean.bootstrap_traj.all.pdf"),
                               phis = phis_for_plot, mark_change_points=T, change_points=changepoints_bootstrap,
                               #assigns_phylo_nodes = assigns_phylo_nodes_sw, #error_bars = mixtures.err,
                               transition_points = transition_points,
                               fitted_data = lapply(mixtures_bootstrap, function(x) x* 100), remove_sigs_below = 0)

    print(paste("Computed example", example))
  }
}

