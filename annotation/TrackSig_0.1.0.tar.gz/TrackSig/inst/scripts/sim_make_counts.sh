#!/bin/bash

# AUTHOR: Yulia Rubanova

. $(dirname "$0")/header.sh $1 $2 $3 $5
. $(dirname "$0")/make_mutation_counts.sh $4
