# BCB430
Work produced for Morris Lab. R package for TrackSig, with VAF clustering informed scoring. 

# load the package in R
devtools::install_github("harrig12/BCB430")
